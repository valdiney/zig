<?php

namespace App\Models;

use System\Model\Model;

class SituacaoPedido extends Model
{
    protected $table = 'situacoes_pedidos';
}
