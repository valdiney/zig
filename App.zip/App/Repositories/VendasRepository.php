<?php

namespace App\Repositories;

use App\Models\Venda;

class VendasRepository
{
    protected $venda;

    public function __construct()
    {
        $this->venda = new Venda();
    }

    public function faturamentoDeVendasNoMes($mes, $ano, $idEmpresa)
    {
        $query = $this->venda->query(
            "SELECT SUM(valor) AS faturamentoDeVendas FROM vendas WHERE id_empresa = {$idEmpresa}
            AND MONTH(created_at) = '{$mes}' AND YEAR(created_at) = '{$ano}'"
        );

        return $query[0]->faturamentoDeVendas;
    }

    public function faturamentoDeVendasNoDia($dia, $mes, $idEmpresa)
    {
        $query = $this->venda->query(
            "SELECT SUM(valor) AS faturamentoDeVendas FROM vendas WHERE id_empresa = {$idEmpresa}
            AND DAY(created_at) = '{$dia}' AND MONTH(created_at) = '{$mes}'"
        );

        return $query[0]->faturamentoDeVendas;
    }

    public function percentualMeiosDePagamento($idEmpresa)
    {
        $query = $this->venda->query("
		  SELECT mpg.legenda, SUM(vendas.valor) AS total,
			ROUND((COUNT(*) / (SELECT COUNT(*) FROM vendas WHERE id_empresa = {$idEmpresa} AND vendas.created_at BETWEEN DATE_ADD(CURRENT_DATE(), INTERVAL -30 DAY) AND CURRENT_DATE())),2) * 100 AS media
			FROM vendas
			INNER JOIN meios_pagamentos AS mpg ON vendas.id_meio_pagamento = mpg.id
			WHERE DATE(vendas.created_at) BETWEEN NOW() - INTERVAL 30 DAY AND NOW()
			AND vendas.id_empresa = {$idEmpresa}
			GROUP BY vendas.id_meio_pagamento
		");

        $legendas = [];
        $medias = [];
        foreach ($query as $valor) {
            array_push($legendas, $valor->legenda);
            array_push($medias, $valor->media);
        }

        return (object)['legendas' => $legendas, 'medias' => $medias];
    }

    public function quantidadeDeVendasRealizadasPorDia(array $periodo, $idEmpresa)
    {
        $query = $this->venda->query(
            "SELECT DATE_FORMAT(created_at, '%d/%m') AS data, COUNT(*) AS quantidade FROM vendas
      WHERE DATE(created_at) BETWEEN NOW() - INTERVAL 30 DAY AND NOW()
      AND id_empresa = {$idEmpresa}
      GROUP BY DAY(created_at) ORDER BY DATE_FORMAT(created_at, '%d/%m') DESC
		");

        return $query;
    }

    public function valorDeVendasRealizadasPorDia(array $periodo, $idEmpresa)
    {
        $query = $this->venda->query("
			SELECT DATE_FORMAT(created_at, '%d/%m') AS data, SUM(valor) AS valor FROM vendas
			WHERE MONTH(created_at) = MONTH(NOW()) AND id_empresa = {$idEmpresa}
			GROUP BY DAY(created_at) ORDER BY DATE_FORMAT(created_at, '%d/%m') ASC
		");

        return $query;
    }

    public function totalVendasPorUsuariosNoMes($idEmpresa, $mes)
    {
        $query = $this->venda->query(
            "SELECT usuarios.id AS idUsuario, usuarios.nome, usuarios.imagem,
            usuarios.nome AS nomeUsuario,
            SUM(vendas.valor) AS valor, DATE_FORMAT(vendas.created_at, '%m'),
            (
            SELECT SUM(vendas.valor) AS total FROM vendas WHERE id_meio_pagamento = 1
            AND id_usuario = usuarios.id AND DATE_FORMAT(vendas.created_at, '%m') = {$mes}
            ) AS Dinheiro,
            (
            SELECT SUM(vendas.valor) AS total FROM vendas WHERE id_meio_pagamento = 2
            AND id_usuario = usuarios.id AND DATE_FORMAT(vendas.created_at, '%m') = {$mes}
            ) AS Credito,
            (
            SELECT SUM(vendas.valor) AS total FROM vendas WHERE id_meio_pagamento = 3
            AND id_usuario = usuarios.id AND DATE_FORMAT(vendas.created_at, '%m') = {$mes}
            ) AS Debito

            FROM vendas INNER JOIN usuarios ON vendas.id_usuario = usuarios.id
            WHERE vendas.id_empresa = 1 AND vendas.id_empresa = {$idEmpresa} AND
            DATE_FORMAT(vendas.created_at, '%m') = {$mes}
            GROUP BY usuarios.nome, usuarios.id ORDER BY vendas.valor DESC
    ");

        //dd($query);

        return $query;
    }

    public function totalVendasUsuariosPorMeioDePagamento($idEmpresa, $idUsuario, $mes)
    {
        $query = $this->venda->query("
      SELECT meios_pagamentos.id, meios_pagamentos.legenda, SUM(vendas.valor) AS total
      FROM vendas INNER JOIN meios_pagamentos ON vendas.id_meio_pagamento = meios_pagamentos.id
      WHERE vendas.id_usuario = {$idUsuario} AND vendas.id_empresa = {$idEmpresa}
      AND DATE_FORMAT(vendas.created_at, '%m') = {$mes}
      GROUP BY vendas.id_meio_pagamento
    ");

        return $query;
    }
}


/*
SELECT DAY(created_at) AS DATA, COUNT(*) FROM vendas
WHERE MONTH(created_at) = MONTH(NOW())
GROUP BY DAY(created_at)
*/
