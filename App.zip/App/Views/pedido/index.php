<div class="row">

	<div class="card col-lg-12 content-div">
		<div class="card-body">
	        <h5 class="card-title"><i class="fas fa-shopping-basket" style="color:#ff99cc"></i> Pedidos</h5>
	    </div>

		<table id="example" class="table tabela-ajustada" style="width:100%">
	        <thead>
	            <tr>
	                <th></th>
	                <th></th>
	            </tr>
	        </thead>
	        <tbody>
	            <tr>
	                
	            </tr>
	        <tfoot></tfoot>
	    </table>

    <br>
	
   </div>
</div>
