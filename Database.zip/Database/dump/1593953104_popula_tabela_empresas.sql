INSERT INTO `empresas` (`id`, `nome`, `email`, `telefone`, `celular`, `id_segmento`, `created_at`, `updated_at`) VALUES
	(1, 'Cliente Teste', '', '', '', 4, '2020-04-23 21:36:33', '2020-04-23 21:36:33');
