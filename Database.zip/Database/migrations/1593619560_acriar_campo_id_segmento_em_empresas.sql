ALTER TABLE `empresas`
	ADD COLUMN `id_segmento` INT NOT NULL AFTER `celular`;