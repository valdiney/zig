<?php

namespace System\ObjetosDeValor;

class UsuarioPermanenciaVO
{
    public const NOME_SESSAO = "usuario_hash";
}
